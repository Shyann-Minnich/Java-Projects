/* DecimalConverter.java
 * This file is the first project of the semester. 
 * It is used to convert decimal values to binary, octal, and hex values. 
 * 
 * Shyann Minnich
 * EECS 1510 - Intro to Object Oriented
 * Dr. Joseph Hobbs
 */

import java.util.Scanner;

/*
 * Main class is to convert Decimal to Binary, Octal, and Hex values.
 */
public class DecimalConverter
{
	//** Main Method is to convert to Binary, Octal, and Hex values.*/
	public static void main(String [] args)
	{
	
		// Create a Scanner
		Scanner input = new Scanner(System.in);
		
		//Prompt the user to enter a decimal value
	
		long decimal = input.nextLong();
		System.out.println(decimal);
		
		// Convert Decimal to Binary
		long binaryValue = 0000000000000000;
		
		//q is quotient. This will be the quotient each time it is divided. 
		long q0 = decimal;
		long q1 = q0/2;
		long q2 = q1/2;
		long q3 = q2/2;
		long q4 = q3/2;
		long q5 = q4/2;
		long q6 = q5/2;
		long q7 = q6/2;
		long q8 = q7/2;
		long q9 = q8/2;
		long q10 = q9/2;
		long q11 = q10/2;
		long q12 = q11/2;
		long q13 = q12/2;
		long q14 = q13/2;
		long q15 = q14/2;
		
		//b is the remainder and individual digit for the binary value
		long b0=q0%2;
		long b1=q1%2;
		long b2=q2%2;
		long b3=q3%2;
		long b4=q4%2;
		long b5=q5%2;
		long b6=q6%2;
		long b7=q7%2;
		long b8=q8%2;
		long b9=q9%2;
		long b10=q10%2;
		long b11=q11%2;
		long b12=q12%2;
		long b13=q13%2;
		long b14=q14%2;
		long b15=q15%2;
		
		//We need to put each of the b into their proper place
		b0*=Math.pow(10, 0);
		b1*=Math.pow(10, 1);
		b2*=Math.pow(10, 2);
		b3*=Math.pow(10, 3);
		b4*=Math.pow(10, 4);
		b5*=Math.pow(10, 5);
		b6*=Math.pow(10, 6);
		b7*=Math.pow(10, 7);
		b8*=Math.pow(10, 8);
		b9*=Math.pow(10, 9);
		b10 =(long) (b10 * Math.pow(10, 10));
		b11*=Math.pow(10, 11);
		b12*=Math.pow(10, 12);
		b13*=Math.pow(10, 13);
		b14*=Math.pow(10, 14);
		b15*=Math.pow(10, 15);
		
		//Now to combine them all together
		binaryValue=b0+b1+b2+b3+b4+b5+b6+b7+b8+b9+b10+b11+b12+b13+b14+b15;
		System.out.printf("%016d", binaryValue);
		
		
		
		
		//Convert Decimal to Octal.
		long octalValue = 000000;
		
		//p is quotient. This will be the quotient each time it is divided. 
		long p0 = decimal;
		long p1 = p0/8;
		long p2 = p1/8;
		long p3 = p2/8;
		long p4 = p3/8;
		long p5 = p4/8;
		
		//c is the remainder and individual digit for the binary value
		long c0=p0%8;
		long c1=p1%8;
		long c2=p2%8;
		long c3=p3%8;
		long c4=p4%8;
		long c5=p5%8;
	
		//We need to put each of the c into their proper place
		c0*=Math.pow(10, 0);
		c1*=Math.pow(10, 1);
		c2*=Math.pow(10, 2);
		c3*=Math.pow(10, 3);
		c4*=Math.pow(10, 4);
		c5*=Math.pow(10, 5);
		
		//Now to combine them all together
		octalValue=c0+c1+c2+c3+c4+c5;
		System.out.println();
		System.out.printf("%06d", octalValue);
		

		//Convert decimal to hex. 
		String hexValue = "";
		
		//r is quotient. This will be the quotient each time it is divided. 
		long r0 = decimal;
		long r1 = r0/16;
		long r2 = r1/16;
		long r3 = r2/16;
		
		//h is the remainder and individual digit for the binary value
		long h0=r0%16;
		long h1=r1%16;
		long h2=r2%16;
		long h3=r3%16;

		//Convert to string
		String x0=h0 + "";
		String x1=h1 + "";
		String x2=h2 + "";
		String x3=h3 + "";
		
		//We need to add a switch case for double digits
		switch(x0) 
		{
			case "10": x0 = "A"; 
			break;
			case "11": x0 = "B";
			break;
			case "12": x0 = "C";
			break;
			case "13": x0 = "D";
			break;
			case "14": x0 = "E"; 
			break;
			case "15": x0 = "F";
			break;
		}
		switch(x1) 
		{
			case "10": x1 = "A"; 
			break;
			case "11": x1 = "B";
			break;
			case "12": x1 = "C";
			break;
			case "13": x1 = "D";
			break;
			case "14": x1 = "E"; 
			break;
			case "15": x1 = "F";
			break;
		}
		switch(x2) 
		{
			case "10": x2 = "A"; 
			break;
			case "11": x2 = "B";
			break;
			case "12": x2 = "C";
			break;
			case "13": x2 = "D";
			break;
			case "14": x2 = "E"; 
			break;
			case "15": x2 = "F";
			break;
		}
		switch(x3) 
		{
			case "10": x3 = "A"; 
			break;
			case "11": x3 = "B";
			break;
			case "12": x3 = "C";
			break;
			case "13": x3 = "D";
			break;
			case "14": x3 = "E"; 
			break;
			case "15": x3 = "F";
			break;
		}
			
		
		//Now to combine them all together
		hexValue=x3+x2+x1+x0;
		System.out.println();
		System.out.printf(hexValue);	
		
	}
		
}
